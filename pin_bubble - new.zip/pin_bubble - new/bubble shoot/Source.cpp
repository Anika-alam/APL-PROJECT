﻿#include"iGraphics.h"
#include<time.h>

int start=1,ending=0,clik=0,mid=0;
int play,about,ext,point=0,level_1=0,level_2=0,level_3=0;
float inc=0;
char name[100],tim[5],points[50],high1[50],high2[50],high3[50];
double dist,animx=60,animy=30,bubblex1=60,bubblex2=290,bubblex3=560,bubblex4=760,bubbley1=60,bubbley2=60,bubbley3=60,bubbley4=60,bubblex5=0,bubbley5=0,bubblex6=450,bubbley6=0,bubblex7=900,bubbley7=0;
double bubble_burst1,bubble_burst2,bubble_burst3,bubble_burst4;
double pinx=0,piny=0;
double pinxarray[3]={pinx,pinx+55,pinx+45},pinyarray[3]={piny,piny+45,piny+55};
double xa[3]={0,600,0},ya[3]={0,0,400},xb[3]={300,900,900},yb[3]={600,200,600};
double xc[3]={0,300,0},yc[3]={0,0,200},xd[3]={600,900,900},yd[3]={600,400,600};
int visible1=1,visible2=1,visible3=1,visible4=1,visible5=1,visible6=1,visible7=1;
clock_t begin, end;
double time_spent;

int i,j,m;
FILE *f1,*f2,*f3;

struct player
{
	char Name[50];
	int c;
}players[100];

struct top
{
	char Name[100];
	int c;
}tops[3];

//
void sort()
{
	int w1,w2,w3,max=0,maxc=0;
	max=players[0].c;
	for(w1=0;w1<=i;w1++)
	{
		if(players[w1].c>max)
		{
			max=players[w1].c;
			maxc=w1;
		}
	}
	strcpy(tops[0].Name, players[maxc].Name);
	tops[0].c= players[maxc].c;
}/*/

 /*
 function iDraw() is called again and again by the system.
 */

int burst(int x, int y)
{
	int r;
	dist=sqrt(pow((double)(pinx-x),2)+pow((double)(piny-y),2));//-----v(x2-x1)2+(y2-y1)2
	if(dist>52)
		return 1;
	else
		return 0;
}

void iDraw()
{
	//place your drawing codes here	
	iClear();

	//-----background design-----//
	iSetColor(255,0,0);
	iFilledRectangle(0,0,900,600);

	iSetColor(255,102,102);
	iFilledPolygon(xa,ya,3);
	iFilledPolygon(xb,yb,3);

	iSetColor(255,51,51);
	iFilledPolygon(xc,yc,3);
	iFilledPolygon(xd,yd,3);
	//-----background design-----//

	if(start)
	{
		if(animy>=600)
			animy=30;
		animy=animy+4.333;

		//-----animate-----//
		iSetColor(255,204,204);

		iCircle(animx+7+(rand()%4+0),animy+27,12);
		iCircle(animx-20-(rand()%4+0),animy+20,7);
		iCircle(animx+(rand()%4+0),animy,5);

		iCircle(animx+300+7+(rand()%4+0),animy-35+27,12);
		iCircle(animx+300-20-(rand()%4+0),animy-35+20,7);
		iCircle(animx+300+(rand()%4+0),animy-35,5);

		iCircle(animx+600+7+(rand()%4+0),animy-25+27,12);
		iCircle(animx+600-20-(rand()%4+0),animy-25+20,7);
		iCircle(animx+600+(rand()%4+0),animy-25,5);

		iCircle(animx+800+7+(rand()%4+0),animy-45+27,12);
		iCircle(animx+800-20-(rand()%4+0),animy-45+20,7);
		iCircle(animx+800+(rand()%4+0),animy-45,5);
		//-----animate-----//

		iSetColor(255,204,204);
		//play-----
		if(play)
			iFilledCircle(264,426,52);
		else
			iFilledCircle(264,426,55);
		//about-----
		if(about)
			iFilledCircle(445,300,52);
		else
			iFilledCircle(445,300,55);
		//exit-----
		if(ext)
			iFilledCircle(626,174,52);
		else
			iFilledCircle(626,174,55);

		iSetColor(255,153,153);
		//play-----
		if(play)
			iFilledCircle(264,426,50);
		else
			iFilledCircle(264,426,53);
		//about-----
		if(about)
			iFilledCircle(445,300,50);
		else
			iFilledCircle(445,300,53);
		//exit-----
		if(ext)
			iFilledCircle(626,174,50);
		else
			iFilledCircle(626,174,53);

		iSetColor(255,204,204);
		//play-----
		if(play)
		{
			iCircle(286,453,7);
			iCircle(299,426,5);
			iFilledCircle(256,418,36);
		}
		else
		{
			iCircle(289,456,7);
			iCircle(302,429,5);
			iFilledCircle(256,418,39);
		}

		//about-----
		if(about)
		{
			iCircle(467,327,7);
			iCircle(480,300,5);
			iFilledCircle(437,292,36);
		}
		else
		{
			iCircle(470,330,7);
			iCircle(483,303,5);
			iFilledCircle(437,292,39);
		}

		//exit-----
		if(ext)
		{
			iCircle(648,201,7);
			iCircle(661,174,5);
			iFilledCircle(618,166,36);
		}
		else
		{
			iCircle(651,204,7);
			iCircle(664,177,5);
			iFilledCircle(618,166,39);
		}

		iSetColor(255,153,153);
		//play-----
		if(play)
			iFilledCircle(259,456,14);
		else
			iFilledCircle(259,456,17);
		//about-----
		if(about)
			iFilledCircle(440,330,14);
		else
			iFilledCircle(440,330,17);
		//exit-----
		if(ext)
			iFilledCircle(621,204,14);
		else
			iFilledCircle(621,204,17);

		iSetColor(255,102,102);
		iText(234,406, "play", GLUT_BITMAP_TIMES_ROMAN_24);
		iText(409,280, "about", GLUT_BITMAP_TIMES_ROMAN_24);
		iText(599,154, "exit", GLUT_BITMAP_TIMES_ROMAN_24);

		play=burst(264,426);
		about=burst(445,300);
		ext=burst(626,174);

	}
	else if(ending)
	{
                sort();
		iSetColor(255,102,102);
		players[i].c=point;
		sprintf(points,"%s got %d points !!!",players[i].Name,players[i].c);
		iText(218,293,points,GLUT_BITMAP_TIMES_ROMAN_24);
		sprintf(high1,"%s got %d points !!!",tops[0].Name,tops[0].c);
		iText(0,0,high1,GLUT_BITMAP_TIMES_ROMAN_24);
	}
	else if(mid)
	{
		//-----measure time-----//
		end = clock();
		time_spent = (double)(end - begin) / CLOCKS_PER_SEC;

		sprintf(tim,"%d",(int)time_spent);
		if(time_spent>=16)
		{
			ending=1;
			mid=0;
		}
		//-----measure time-----//

		iSetColor(255,102,102);
		iText(445,300,tim,GLUT_BITMAP_TIMES_ROMAN_24);

		iSetColor(255,0,0);
		iText(274,115,tim,GLUT_BITMAP_TIMES_ROMAN_24);
		iText(637,474,tim,GLUT_BITMAP_TIMES_ROMAN_24);

		bubbley1+=3.333;

		if(bubbley1>600)
		{
			bubbley1=10+rand()%50+10;
			bubblex1=60+rand()%(-50)+50;
		}
		if(visible1==0)
		{
			bubbley1=-80;
			visible1=1;
		}

		bubbley2+=3.333;

		if(bubbley2>600)
		{
			bubbley2=10+rand()%50+10;
			bubblex2=290+rand()%(-50)+50;
		}
		if(visible2==0)
		{
			bubbley2=-80;
			visible2=1;
		}

		bubbley3+=3.333;

		if(bubbley3>600)
		{
			bubbley3=10+rand()%50+10;
			bubblex3=560+rand()%(-50)+50;
		}
		if(visible3==0)
		{
			bubbley3=-80;
			visible3=1;
		}

		bubbley4+=3.333;

		if(bubbley4>600)
		{
			bubbley4=10+rand()%50+10;
			bubblex4=760+rand()%(-50)+50;
		}
		if(visible4==0)
		{
			bubbley4=-80;
			visible4=1;
		}

		//-----kalo bubble-----//
		bubbley5+=3.333;

		if(bubbley5>600)
		{
			bubbley5=10+rand()%50+10;
			bubblex5=rand()%700+100;
		}
		if(visible5==0)
		{
			bubbley5=-80;
			visible5=1;
		}

		bubbley6+=3.333;

		if(bubbley6>600)
		{
			bubbley6=10+rand()%50+10;
			bubblex6=bubblex5+rand()%500+100;
		}
		if(visible6==0)
		{
			bubbley6=-80;
			visible6=1;
		}

		bubbley7+=3.333;

		if(bubbley7>600)
		{
			bubbley7=10+rand()%50+10;
			bubblex7=rand()%500+100;
		}
		if(visible7==0)
		{
			bubbley7=-80;
			visible7=1;
		}
		//-----kalo bubble-----//

		//-----bubble-----//
		if(visible1)
		{
			iSetColor(255,204,204);
			iFilledCircle(bubblex1,bubbley1,52);
			iSetColor(255,153,153);
			iFilledCircle(bubblex1,bubbley1,50);
			iSetColor(255,204,204);
			iCircle(bubblex1+22,bubbley1+27,7);
			iCircle(bubblex1+35,bubbley1,5);
			iFilledCircle(bubblex1-8,bubbley1-8,36);
			iSetColor(255,153,153);
			iFilledCircle(bubblex1-5,bubbley1+30,14);
		}

		if(visible2)
		{
			iSetColor(255,204,204);
			iFilledCircle(bubblex2,bubbley2,52);
			iSetColor(255,153,153);
			iFilledCircle(bubblex2,bubbley2,50);
			iSetColor(255,204,204);
			iCircle(bubblex2+22,bubbley2+27,7);
			iCircle(bubblex2+35,bubbley2,5);
			iFilledCircle(bubblex2-8,bubbley2-8,36);
			iSetColor(255,153,153);
			iFilledCircle(bubblex2-5,bubbley2+30,14);
		}

		if(visible3)
		{
			iSetColor(255,204,204);
			iFilledCircle(bubblex3,bubbley3,52);
			iSetColor(255,153,153);
			iFilledCircle(bubblex3,bubbley3,50);
			iSetColor(255,204,204);
			iCircle(bubblex3+22,bubbley3+27,7);
			iCircle(bubblex3+35,bubbley3,5);
			iFilledCircle(bubblex3-8,bubbley3-8,36);
			iSetColor(255,153,153);
			iFilledCircle(bubblex3-5,bubbley3+30,14);
		}

		if(visible4)
		{
			iSetColor(255,204,204);
			iFilledCircle(bubblex4,bubbley4,52);
			iSetColor(255,153,153);
			iFilledCircle(bubblex4,bubbley4,50);
			iSetColor(255,204,204);
			iCircle(bubblex4+22,bubbley4+27,7);
			iCircle(bubblex4+35,bubbley4,5);
			iFilledCircle(bubblex4-8,bubbley4-8,36);
			iSetColor(255,153,153);
			iFilledCircle(bubblex4-5,bubbley4+30,14);
		}

		if(visible5)
		{
			iSetColor(41,41,48);
			iFilledCircle(bubblex5,bubbley5,52);
			iSetColor(200,199,207);
			iFilledCircle(bubblex5,bubbley5,50);
			iSetColor(41,41,48);
			iCircle(bubblex5+22,bubbley5+27,7);
			iCircle(bubblex5+35,bubbley5,5);
			iFilledCircle(bubblex5-8,bubbley5-8,36);
			iSetColor(200,199,207);
			iFilledCircle(bubblex5-5,bubbley5+30,14);
		}

		if(visible6)
		{
			iSetColor(41,41,48);
			iFilledCircle(bubblex6,bubbley6,52);
			iSetColor(200,199,207);
			iFilledCircle(bubblex6,bubbley6,50);
			iSetColor(41,41,48);
			iCircle(bubblex6+22,bubbley6+27,7);
			iCircle(bubblex6+35,bubbley6,5);
			iFilledCircle(bubblex6-8,bubbley6-8,36);
			iSetColor(200,199,207);
			iFilledCircle(bubblex6-5,bubbley6+30,14);
		}

		if(visible7)
		{
			iSetColor(41,41,48);
			iFilledCircle(bubblex7,bubbley7,52);
			iSetColor(200,199,207);
			iFilledCircle(bubblex7,bubbley7,50);
			iSetColor(41,41,48);
			iCircle(bubblex7+22,bubbley7+27,7);
			iCircle(bubblex7+35,bubbley7,5);
			iFilledCircle(bubblex7-8,bubbley7-8,36);
			iSetColor(200,199,207);
			iFilledCircle(bubblex7-5,bubbley7+30,14);
		}
		//-----bubble-----//

		if(!burst(bubblex1,bubbley1))
		{
			point++;

			bubbley1=10+rand()%50+10;
			bubblex1=60+rand()%(-50)+50;
			visible1=0;
			PlaySound(TEXT("music//pops.wav"),NULL, SND_ASYNC);
		}

		if(!burst(bubblex2,bubbley2))
		{
			point++;

			bubbley2=10+rand()%50+10;
			bubblex2=290+rand()%(-50)+50;
			visible2=0;
			PlaySound(TEXT("music//pops.wav"),NULL, SND_ASYNC);
		}

		if(!burst(bubblex3,bubbley3))
		{
			point++;

			bubbley3=10+rand()%50+10;
			bubblex3=560+rand()%(-50)+50;
			visible3=0;
			PlaySound(TEXT("music//pops.wav"),NULL, SND_ASYNC);
		}

		if(!burst(bubblex4,bubbley4))
		{
			point++;

			bubbley4=10+rand()%50+10;
			bubblex4=760+rand()%(-50)+50;
			visible4=0;
			PlaySound(TEXT("music//pops.wav"),NULL, SND_ASYNC);
		}

		if(!burst(bubblex5,bubbley5))
		{
			point--;

			bubbley5=10+rand()%50+10;
			bubblex5=rand()%700+100;
			visible5=0;
			PlaySound(TEXT("music//pops.wav"),NULL, SND_ASYNC);
			ending=1;
		}

		if(!burst(bubblex6,bubbley6))
		{
			point--;

			bubbley6=10+rand()%50+10;
			srand(time==NULL);
			bubblex6=bubblex5+rand()%500+100;
			visible6=0;
			PlaySound(TEXT("music//pops.wav"),NULL, SND_ASYNC);
			ending=1;

		}

		if(!burst(bubblex7,bubbley7))
		{
			point--;

			bubbley7=10+rand()%50+10;
			srand(time==NULL);
			bubblex7=bubblex6+rand()%500+100;
			visible7=0;
			PlaySound(TEXT("music//pops.wav"),NULL, SND_ASYNC);
			ending=1;

		}

	}

	//-----pin design r control er part-----//
	pinxarray[0]=pinx;pinxarray[1]=pinx+55;pinxarray[2]=pinx+45;
	pinyarray[0]=piny;pinyarray[1]=piny+45;pinyarray[2]=piny+55;

	iSetColor(64,64,64);
	iFilledPolygon(pinxarray,pinyarray,3);
	iSetColor(128,128,128);
	iFilledCircle(pinx+50,piny+50,21);
	iSetColor(127,0,255);
	iFilledCircle(pinx+50,piny+50,20);
	//-----pin design r control er part-----//

	//-----debug section-----//
	/*/
	iSetColor(0,0,0);

	iPoint(264,426,1);
	iPoint(445,300,1);
	iPoint(626,174,1);
	/*/
	system("cls");
	printf("%f %f\n%d %d",pinx,piny,point,players[0].c);
	//-----debug section-----//
}

/* 
function iMouseMove() is called when the user presses and drags the mouse.
(mx, my) is the position where the mouse pointer is.
*/
void iMouseMove(int mx, int my)
{
	//place your codes here
	//-----mouse nai korar r control er part-----//-----!!!-----andaje
	if(pinx>=0 && pinx<=900 && piny>=0 && piny<=600)// frame er vetor
	{
		mouse_event(MOUSEEVENTF_LEFTUP, MOUSEEVENTF_ABSOLUTE, MOUSEEVENTF_ABSOLUTE, 0, 0);
		ShowCursor(false);
	}
	else// frame er baire
	{
		mouse_event(MOUSEEVENTF_LEFTUP, MOUSEEVENTF_ABSOLUTE, MOUSEEVENTF_ABSOLUTE, 0, 0);
		ShowCursor(true);
	}
	//-----mouse nai korar r control er part-----//-----!!!-----andaje
	pinx=mx;
	piny=my;
}

/* 
function iMouse() is called when the user presses/releases the mouse.
(mx, my) is the position where the mouse pointer is.
*/
void iMouse(int button, int state, int mx, int my)
{
	if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		//place your codes here
		if(play==0)
		{
			PlaySound(TEXT("music//pops.wav"),NULL, SND_ASYNC);
			start=0;
			mid=1;
			begin = clock();

		}

		if(about==0)
		{
			PlaySound(TEXT("music//pops.wav"),NULL, SND_ASYNC);
		}

		if(ext==0)
		{
			PlaySound(TEXT("music//pops.wav"),NULL, SND_ASYNC);
			ShowCursor(true);
			exit(0);
		}
	}
	else
		clik=0;
	if(button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
		//place your codes here	
	}

}

/*
function iKeyboard() is called whenever the user hits a key in keyboard.
key- holds the ASCII value of the key pressed. 
*/
void iKeyboard(unsigned char key)
{
	if(key == 27) // ASCII code for ESC = 27
	{
		
		i++;
		f1=fopen("player data.txt","w+");
		for(j=0;j<i;j++)
			fprintf(f1,"%s %d\n",players[j].Name,players[j].c);
		fclose(f1);
		f2=fopen("size.txt","w+");
		fprintf(f2,"%d",i);
		fclose(f2);
		f3=fopen("top.txt","w+");
		fprintf(f3,"%s %d\n",tops[0].Name,tops[0].c);
		fclose(f3);
		ShowCursor(true);
		exit(0);
	}

	if(key == 32) // ASCII code for SPACW BAR = 32
	{
		//place your codes for other keys here
	}

}

/*
function iSpecialKeyboard() is called whenver user hits special keys like-
function keys, home, end, pg up, pg down, arraows etc. you have to use 
appropriate constants to detect them. A list is:
GLUT_KEY_F1, GLUT_KEY_F2, GLUT_KEY_F3, GLUT_KEY_F4, GLUT_KEY_F5, GLUT_KEY_F6, 
GLUT_KEY_F7, GLUT_KEY_F8, GLUT_KEY_F9, GLUT_KEY_F10, GLUT_KEY_F11, GLUT_KEY_F12, 
GLUT_KEY_LEFT, GLUT_KEY_UP, GLUT_KEY_RIGHT, GLUT_KEY_DOWN, GLUT_KEY_PAGE UP, 
GLUT_KEY_PAGE DOWN, GLUT_KEY_HOME, GLUT_KEY_END, GLUT_KEY_INSERT 
*/
void iSpecialKeyboard(unsigned char key)
{
	if(key == GLUT_KEY_UP)
	{

	}

	if(key == GLUT_KEY_DOWN)
	{

	}
	//place your codes for other keys here
}

int main()
{
	system("color A");
	f2=fopen("size.txt","r+");
	fscanf(f2,"%d",&i);
	//place your own initialization codes here.
	printf("enter player's name: ");
	fflush(stdin);
	gets(players[i].Name);
	f1=fopen("player data.txt","r+");
	for(j=0;j<i;j++)
		fscanf(f1,"%s %d",&players[j].Name,&players[j].c);
	fclose(f1);
	f3=fopen("top.txt","r+");
	fscanf(f3,"%s %d",&tops[0].Name,&tops[0].c);
	fclose(f3);
	srand(time==NULL);
	iInitialize(900, 600, "pin_bubble");
	return 0;
}